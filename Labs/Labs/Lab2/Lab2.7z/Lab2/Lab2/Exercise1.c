#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

// I have a problem with the spaces!!!! 
//what is %6d -%6d, the diffrence between tab in the keyboard and \t



int main()
{
	printf("a\ta\n");
	printf("a________\n");
	printf("a	a");
	/*
	int num;
	printf("Enter number:");
	scanf("%d", &num);
	printf("Number\tSquare\tCube\n");
	printf("%4d%5d	%-5lf	\n", num, 36, pow(num, 2));
	printf("%7d%7lf%-6lf\n", num+1, pow(num+1, 2), pow(num+1, 3));
	printf("%7d%7lf%-6lf\n", num+2, pow(num+2, 2), pow(num+2, 3));
	printf("%7d%7lf%-6lf\n", num+3, pow(num+3, 2), pow(num+3, 3));
	printf("%7d%7lf%-6lf\n", num+4, pow(num+4, 2), pow(num+4,3));

	*/
	return 0;
}
