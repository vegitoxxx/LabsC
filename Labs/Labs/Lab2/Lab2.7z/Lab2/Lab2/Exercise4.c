#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

int main() 
{
	float a, b,x;
	printf("Given the equation a^x=b\nEnter a and b,respectively please: ");
	if (scanf("%f%f", &a, &b) == 2)
	{
		x = log(b) / log(a);
		printf("x is: %g", x);
	}
	else
		printf("Failed to read two floats");
	
	return 0;
}