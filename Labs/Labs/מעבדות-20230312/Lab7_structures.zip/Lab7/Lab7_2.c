#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct stud
{
	char *name;
	int marks[4];
	float avg;
}student;


student* Create_Class(int);
void Avg_Mark(student*);
void Print_One(student*);


int main()
{
	int size,i;
	student *arr;
	printf("\nEnter the number of students:");
	scanf("%d",&size);



	return 0;


}

student* Create_Class(int size)
{
	
}


void Avg_Mark(student* s)
{
	
}


void Print_One(student* s)
{

}

