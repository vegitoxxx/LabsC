#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node
{
	char code[11];
	char *name;
	char Dep[4];
	int marks[3];
	float avg;
	struct node* next;
}std;

void Error_Msg(char* str);
std* FromFileToList(FILE *in);
std* Delete_Stud(std* toDel,std* head);
std* DeleteList(std* head);
void PrintList(std* head);
std* FindMax(std* head);

int main()
{
	int i;
	FILE *f;
	std *Head=NULL, *temp;

	if((f=fopen("List.txt","rt")) == NULL)
           Error_Msg("input error");
	Head=FromFileToList(f);
        if(Head == NULL)
          Error_Msg("The input file is empty");

        fclose(f);
	printf("\nThe list is:");
	PrintList(Head);
	
	temp = FindMax(Head);
        printf("\n\nthe student with max average:\n");
	printf("%s %s %s ",temp->code,temp->name,temp->Dep);
        for(i=0;i<3;i++)
          printf(" %d ",temp->marks[i]);

	printf("\n\nThe list after change:");
	Head=Delete_Stud(FindMax(Head),Head);
	PrintList(Head);
	Head = DeleteList(Head);        /*Head = NULL */
        return 0;
}

void Error_Msg(char* str)
{
	printf("\n%s",str);
        exit(1);
}



std* Delete_Stud(std* toDel,std* head)
{
  if(head == NULL)
    return NULL;

  if(toDel==head)
  {

  }
  else
  {

  }
  return head;
}
