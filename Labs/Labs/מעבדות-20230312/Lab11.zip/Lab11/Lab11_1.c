#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 5




int main()
{
	int i;
	Item *Head=NULL, *temp;
	for(i=1;i<=N;i++){		

	}

	
	printf("\n\nThe List is:  ");
	while(       )
        {
		printf("%d %s --> ",);
	
	}

	while(){
	
	}
        return 0;
}




