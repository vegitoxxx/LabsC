#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>

#define  N  6
#define  LENGTH 30

void Insert( bool(*f)(void *, void *), void* , void **, int);
bool Str_Comp(void *, void *);
bool IsFull(int);


int main()
{
  char* Array[N];
  void* PArray[N];
  int i,CurrentCount=0;
  char TempStr[LENGTH];

  printf("Enter up to %d strings with space between them,'end' to finish ",N);
  scanf("%s", TempStr);

  while( strcmp(TempStr,"end")!=0)    /* not the same string*/
  {
    
    if(IsFull(CurrentCount) == false) 
    {
      Array[CurrentCount] = (char*)malloc(strlen(TempStr)+1); /*allocate the string memory*/
      strcpy(Array[CurrentCount], TempStr);   
      Insert(Str_Comp, Array[CurrentCount], PArray,CurrentCount);    /*call the general function*/
      scanf("%s", TempStr);
      CurrentCount++;
    }
    else  
    {
      printf("The array is full");
      break;
    }
 }
 printf("\nYour sorted array is:\n");
 for(i = 0; i < CurrentCount; i++)
   printf(" %s " , (char*)PArray[i]);

 for(i = 0; i < CurrentCount; i++)
    free(Array[i]);

  return 0;
}


bool IsFull(int count)
{
 if (count == N)
  return true;
 return false;
}
	

bool Str_Comp(void *FirstElement, void *SecondElement)
{
  if( strcmp( (char*)FirstElement, (char*)SecondElement) > 0 )
    return true;
  return false;
}




