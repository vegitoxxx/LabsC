#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>

#define  N  6

void Insert( bool(*f)(void *, void *), void* , void **, int);
bool Int_Comp(void *, void *);
bool IsFull(int);



int main()
{
  int Array[N], Value, i,CurrentCount = 0;
  void* PArray[N];                        /*pointers array*/

  printf("Enter up to %d numbers, -999 to stop",N);
  scanf("%d", &Value);

  while( Value != -999)  
  {           
    if(IsFull(CurrentCount) == false) 
    {
        Array[CurrentCount] = Value;
        Insert(Int_Comp, &Array[CurrentCount], PArray,CurrentCount);  /*call the general function*/
        scanf("%d", &Value);
        CurrentCount++;
     }
    else  
    {
      printf("The array is full");
      break;
    }
 }
 printf("\n Your sorted array is:\n");             /*print the array in sorted order*/
 for(i=0; i < CurrentCount; i++)
    printf(" %d " ,*(int*)PArray[i]);

 return 0;
}



bool IsFull(int count)
{
 if (count == N)
  return true;
 return false;
}


bool Int_Comp(void *FirstElement, void *SecondElement)
{
  if( *(int*)FirstElement > *(int*)SecondElement)
    return true;
  return false;
}

